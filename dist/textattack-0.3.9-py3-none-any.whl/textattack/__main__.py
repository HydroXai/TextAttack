#!/usr/bin/env python

if __name__ == "__main__":
    import textattack

    textattack.commands.textattack_cli.main()
