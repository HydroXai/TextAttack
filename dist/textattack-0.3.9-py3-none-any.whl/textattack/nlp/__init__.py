"""

TextAttack nlp Package
==================================

"""

from .entity_extraction import EntityExtraction

from . import (
    notebooks
)

# name = "nlp"
